<html>
<head>
<title>Get Your Html Code</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">


<head>
<style type="text/css">
<!--
td {
	font-family: Tahoma;
	font-size: 11px;
	color: #333333;
	text-decoration: none;
	border: none;
}
font {
	font-family: Tahoma;
	font-size: 11px;
	color: #1890E1;
	text-decoration: none;
	border: none;
	font-weight: bold;
}
.f {
	font-family: Tahoma;
	font-size: 11px;
	color: #FF2D00;
	text-decoration: none;
	border: none;
	font-weight: normal;
}
a {
	font-family: Tahoma;
	font-size: 10px;
	font-weight: bold;
	color: #FB5E3C;
	text-decoration: none;
	border: none;
}
.a {
	font-family: Tahoma;
	font-size: 11px;
	font-weight: normal;
	color: #FFFFFF;
	text-decoration: none;
	border: none;
}
.a1 {
	font-family: Tahoma;
	font-size: 11px;
	color: #40A3D8;
	font-weight: normal;
	text-decoration: none;
	border: none;
}
img {
	text-decoration: none;
	border: none;
}


-->
</style> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Language" content="en-us">
</head>

<body bgcolor=#FFFFFF leftmargin=0 topmargin=0 marginwidth=0 marginheight=0">
<table width=760 height="100%" border=0 cellpadding=0 cellspacing=0 align="center">
  
<tr> 
    <td width="1" bgcolor="#000000" rowspan="100"><img src="images/spacer.gif" width=1 height=1 alt=""></td>
    <td> <img src="images/spacer.gif" width=172 height=1 alt=""></td>
    <td> <img src="images/spacer.gif" width=22 height=1 alt=""></td>
    <td> <img src="images/spacer.gif" width=104 height=1 alt=""></td>
    <td> <img src="images/spacer.gif" width=66 height=1 alt=""></td>
    <td> <img src="images/spacer.gif" width=20 height=1 alt=""></td>
    <td> <img src="images/spacer.gif" width=92 height=1 alt=""></td>
    <td> <img src="images/spacer.gif" width=92 height=1 alt=""></td>
    <td> <img src="images/spacer.gif" width=91 height=1 alt=""></td>
    <td> <img src="images/spacer.gif" width=101 height=1 alt=""></td>
    <td width="1" bgcolor="#000000" rowspan="100"><img src="images/spacer.gif" width=1 height=1 alt=""></td>
  </tr>

  <tr> 
    <td colspan=9 width="760" height="29"><img src="images/top.jpg"></td>
  </tr>
  <tr> 
    <td width=760 height=156 colspan=9>
			<script src="embedflash.js"></script>        
    </td>
  </tr>
  <tr> 
    <td colspan=2><img src="images/1_sup.jpg" width=194 height=95 alt=""></td>
    <td colspan=3><img src="images/2.jpg" width=190 height=95 alt=""></td>
    <td colspan=2><img src="images/3.jpg" width=184 height=95 alt=""></td>
    <td colspan=2><img src="images/4_sup.jpg" width=192 height=95 alt=""></td>
  </tr>
  
    <tr> 
    <td width=760 height=100% background="images/bg.jpg"> <table width="172" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td style="padding-left:20">
          
          <p>
			<br><br><br>
			<br><br>
			</td>
			<tr> 
          <td height="100%"></td>
        </tr>
        <tr> 
          <td><img src="images/im_bottom.gif"></td>
        </tr>
      </table></td>
      
          <td width=588 height=100% colspan=8 background="images/bg1.jpg"> <table width="588" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td style="padding-top:20;padding-bottom:20"><img src="images/line.gif"><br>
			<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>






        </tr>
        <tr> 
          <td style="padding-left:30;padding-right:40"><font>Get html code</font><p>
To use this online user service just copy the HTML code below into your website and<br>
replace &quot;<font color="#FF0000">CHANGE_TO_YOUR_DOMAIN</font>&quot; with the page the script will be used on.<br>
(Ex. www.yourdomain.com/index.html)</p>
<p>
<span lang="EN-US"><b>The text ad is what keeps this service free so don't remove it.<br>
If you remove the ad link we will disable your service and you will not be 
welcome here anymore.<br>
</b></span>
<br>
<span lang="EN-US"><i>If you are using frames you have to enter the destination 
url or the script will not work</i><br>
<textarea rows="8" cols="51" name="htmlcode">
<!-- Start FastOnlineUsers.com -->
<a href="http://www.fastonlineusers.com"><script type="text/javascript" src="http://fastonlineusers.com/on3.php?d=www.CHANGE_TO_YOUR_DOMAIN.com"></script> online</a><br><a href="http://www.glowingcasino.com">Online Casinos</a>
<!-- End FastOnlineUsers.com --></textarea><br>You are not allowed to modify the 
code unless the section with &quot;<font color="#FF0000">CHANGE_TO_YOUR_DOMAIN</font>&quot;<br>
You can move the ad text to another place on the page if that suit you better. 
(It has to be on the same page as the script).<br>
Every time you refresh the page you will se another text ad, choose the one that
match your site.</span></p>
<p><span lang="en-us">This is the only thing you have to do, to use our online 
user script.<br>
Read the <a href="terms.html">terms and condition</a></span></p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <br> &nbsp;</p>
			<p>&nbsp;</td>
        </tr>
        <tr> 
          <td height="100%"></td>
        </tr>
      </table>
      
      </td>

  </tr>

  <tr> 

    <td width=760 height=55 colspan=9 background="images/bg2.jpg" align="center"> 

      <img src="images/icon1.gif">&nbsp;&nbsp;<a class="a" href="http://www.fastonlineusers.com">Online Users</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 

      <img src="images/icon1.gif">&nbsp;&nbsp;<a class="a" href="htmlcode.php">Html Code</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 

      <img src="images/icon1.gif">&nbsp;&nbsp;<a class="a" href="terms.html">Terms</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 

      <img src="images/icon1.gif">&nbsp;&nbsp;<a rel="nofollow" class="a" href="privacy.html">Privacy</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      
      <img src="images/icon1.gif">&nbsp;&nbsp;<a class="a" href="contact.html">Contact Us</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
      
      <img src="images/icon1.gif">&nbsp;&nbsp;<a class="a" href="http://blog.fastonlineusers.com">Free Online Articles</a>&nbsp;&nbsp;&nbsp;&nbsp;</td>

  </tr>

  <tr>

    <td width=760 height=40 colspan=9 background="images/bg3.jpg" align="center"> 

      Copyright 2011, <b style="color:#40A3D8">Fast</b><b>OnlineUsers.com</b> All 

      rights reserved.&nbsp;<!-- Start FastWebCounter.com  -->
<a href="http://www.fastwebcounter.com" title="Free Web Counter"><script src="http://fastwebcounter.com/secure.php?s=fastonlineusers.com"></script> hits</a>&nbsp;since 
13 November 2005

<!-- End FastWebCounter.com  --></td>

  </tr>

</table>




</body>

</html>