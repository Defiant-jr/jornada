document.write('36');
