<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>

<title>Site Meter - Counter and Statistics Tracker</title>

<meta name="description" content="A fast, free Web counter that features custom counters styles. Site Meter creates dynamic 3D charts showing visitors, page views, country maps, visit durations and much more!">
<meta name="keywords" content="webstats, web counter, hit counter, free counter, Counter, web page counter, free web counter, free hit counter, tracker, web tracker, webtracker, free web tracker, webcounter, site statistics, page views, visits, javascript, web stats, log analyzer, log files, visitor reports, hits, visit reports, frontpage web counter, pagemill counter, dreamweaver counter, frontpage counter, site traffic, statistics log, traffic">


<LINK REL="SHORTCUT ICON" HREF="favicon.ico" >
<link rel="stylesheet" href="css/global.css" type="text/css">

<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://weblog.sitemeter.com/feed/" />
</head>


 
<body>
<div id="page" align="center">
 
					<div id="containerthin">
				 
	<table id="Table_01" width="783" height="500" border="0" cellpadding="0" cellspacing="0" valign="top" border="0" align="center">
		<tr>
			<td valign="middle"></td>
		</tr>
		<tr>
			<td align="center">

				<table id="Table_02" width="775" height="500" border="0" cellpadding="0" cellspacing="0" valign="top" border="0" style>
				
					<tr>
						<td colspan="2" valign="top" height="90">
						
<script LANGUAGE="JavaScript">
function callSearch()
{
document.siteform.submit;
}

function callfunction()
{
document.siteform.submit();
}

</script>
<form action="default.asp" method="POST" name="siteform" id="siteform" style="margin-top:0">
<input type="hidden" name="lastaction" value="NOTEBOOKS.COM">
<input type="hidden" name="lastarea" value="">
<input type="hidden" name="lastpage" value="">



<table id="Table_01" border="0" cellpadding="0" cellspacing="0" align="left" style="margin-top:25px; width:775px;">
	<tr valign="top">
		<td width="326" height="44"><a href="/"><img src="images/sitemeter_logo.gif" width="226" height="44" alt="sitemeter" border=0></a></td>
	    <td  height="44" width="154"><img src="images/premium-prices_04.jpg" width="185" height="54" alt=""></td>
		<td width="150">
			<input style="margin-top:2px;" type='text' id='USERID'  class='detailedViewTextBox1'  name='USERID' value='' size="15" tabindex="1"><br>
			<input style="margin-top:5px;" type='password' name='PASSWORD'  class='detailedViewTextBox1' id='PASSWORD' value="" size="15" tabindex="2">
		</td>
		<td nowrap="nowrap" style="font-size:10px;font-family:arial;" width="150">
			<input tabindex=3 type="image" name="Login" src="images\LoginButton.jpg" width="70" height="25" border="0" onclick="javascript:callfunction();"><input  tabindex=3 type="hidden" name='LOGIN_BUTTON' value='login'><br>
			<input type="checkbox" name="Remember" value="True">Remember&nbsp;Me&nbsp;<br>
			&nbsp;<a href="/?a=loginform">forgot codename/password?</a>
   		</td>
	</tr>

	<tr><td colspan="4" height="11"><img src="images/greenbar.gif" width="775" height="6" alt=""></td></tr>
</table>
</form>
<script language="JavaScript" type="text/javascript">
<!--
	document.siteform.USERID.focus();
// -->
</script>&nbsp;
						</td>
					</tr>
			
					 				
				<tr>
				
							
							<td valign ="top" width="175" height="350" align="left">
							<table bgcolor="#FFFFFF" border="0" cellspacing="0" cellpadding="0" width="181" >
   
     <tr height="15">
  		
  			 	<td class='menuheader' height="15" width="179">
  			 		 <a href=".?a=home" STYLE="text-decoration:none">
   				<font size='2' face='Arial' color=White>&nbsp;&nbsp;home</font></a></td>
   	 </tr>
  
  <tr height="5">
	<Td width="179"></td>
			</tr>
			
   		<tr height="15">   
			<td height="15" class="menuheader" width="179" >&nbsp&nbsp learn more</td>
		</tr>
		
	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=howworks">How Does Site Meter Work?</a></td>
	  </tr>
	  
	  <tr height="15">
        <td class="menuitem" height="15" width="179" >Site Meter Basic</td>
	  </tr>
 	  <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href="/flash/basic_account/basic_account.html" target=_blank>Tour</a>      </td>
        </tr>     
	  <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href=".?a=samplestats&HELP=ON">Demo Stats</a>      </td>
        </tr>
        
        <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href=".?a=counterstyles">Meter Options</a>    	    </td>
        </tr>
        
        <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href=".?a=signupoptions">Sign Up</a>    </td>
        </tr>
        
   	    <tr height="15">
           <td class="menuitem" height="15" width="179" >Site Meter Premium</td>
        </tr>
        

 	  <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href="/flash/premium_tour/premium_tour.html" target=_blank>Tour</a>      </td>
        </tr>    

        <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href=".?a=sampleprostats&HELP=ON">Demo Stats</a>      </td>
        </tr>

        <tr height="15">
        	<td class="menusubitem" height="15" width="179" ><a href=".?a=premiumprices">Pricing</a> </td>
        </tr>
    
	    <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href=".?a=signupoptions">Sign Up</a>	        </td>
        </tr>
        
        <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=productcomparison">Product Comparison</a></td>
	  	</tr>  
	  
	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href="http://support.sitemeter.com/index.php?_m=knowledgebase&_a=view&parentcategoryid=1&pcid=0&nav=0">FAQ-General Info</a></td>
	  </tr>
       
       
      <tr height="15">
        <td class="menuheader" height="15" width="179" >&nbsp&nbsp news + announcements</td>
	  </tr>	          
    
	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a  target="_blank" href="http://sitemeter.wordpress.com/">News/Announcements Blog </a></td>
	  </tr>  
	
	     <tr height="15">
    
        <td class="menuheader" height="15" width="179" >&nbsp&nbsp support + service</td>
	  </tr>	          
    
		<tr height="15">
        <td class="menuitem" height="15" width="179" ><a href="http://support.sitemeter.com">KnowledgeCenter</a></td>
		</tr> 

		<tr height="15">
        <td class="menuitem" height="15" width="179" ><a href="http://support.sitemeter.com/index.php?_m=tickets&_a=submit">Submit Support Request</a></td>
		</tr> 

	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=signupoptions">Upgrade Account</a></td>
	  </tr> 
	  
     <tr height="15">
        <td class="menuheader" height="15" width="179" >&nbsp&nbsp about us</td>
	  </tr>	          
      
      <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=contact">Contact Info</a></td>
	  </tr>  
	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=privacy">Privacy Policy</a></td>
	  </tr>      
	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=joinus">Join Us</a></td>
	  </tr> 
		  <tr height="15">
        <td  height="15" width="179" >&nbsp;</td>
	  </tr>   
	 <tr >
        <td  width="179" ><!--[if lt IE 7.]>
<script defer type="text/javascript" src="Js/pngfix.js"></script>
<![endif]-->
<table border=0 cellpadding=0 cellspacing=0>
	<tr><td><img src="images/partners_top_border.gif" width=212 height=16></td></tr>
	<tr>
		<td valign=top background="images/partners_repeat_border.gif" style="background-repeat: repeat-y; ">
		<div class=boxTitleFont>&nbsp;&nbsp;&nbsp;site meter partners<br></div>
		<table align=center style="padding-top:4px;">
			
			<tr>
				<td align=center style="padding-left:7px;"><a href="http://webanalyticsbook.com/" alt="Web Analytics Book" target=_blank border=0>
<img border='0' src='images/webanalytics.gif' width=150 height=43></a></td>
			</tr>
			<tr>
				<td align=center style="padding-left:7px; "><a href="http://blogherald.com/" alt="Blog Herald" target=_blank>
<img border='0' src='images/blogherald.gif' width=150 height=43></a></td>
			</tr>
			<tr>
				<td align=center style="padding-left:7px; "><a href="http://www.readwriteweb.com/" alt="Read/Write Web" target=_blank>
<img border='0' src='images/readwrite.gif' width=150 height=43></a></td>
			</tr>
			

			
		</table>
		<div class=boxTitleFont><br>&nbsp;&nbsp;&nbsp;site meter eco-ranking<br></div>
		<table align=center style="padding-top:4px;">
			<tr>
				<td align=center style="padding-left:7px; "><a href="http://truthlaidbear.com/ecotraffic.php" alt="The Truth Laid Bear" target=_blank>
					<img border='0' src='images/ttlb.png' width=150 height=43></a>
				</td>
			</tr>
		</table>
		</td>
	</tr>


	<tr><td><img src="images/partners_bottom_border.gif" width=212 height=15></td></tr>
</table> </td>
	  </tr> 	 

 <tr>
        <td width="179"> 
<table border=0 cellpadding=0 cellspacing=0>
	<tr><td><img src=images/homepage/testimonial_top_border.gif></td></tr>
	<tr><td valign=top background="images/homepage/testimonial_repeat_border.gif" height=205 style="background-repeat: repeat-y; ">
		<span class=boxTitleFont>&nbsp;&nbsp;&nbsp;testimonials</span>
		<div style="padding-left:13px; padding-top:2px; padding-right:10px; width:190px; vertical-align:middle;">
			<table height="235px;" width="179">
			<tr><td width="171"><div class=testimonialFont>"I love Site Meter. I recommend it to everyone..."</div>
			<div class=testimonialFontQuote style="width: 161; height: 19"><a href="http://simplyrecipes.com/" target="_blank">EB - SimplyRecipes</div></td></tr>
				
			<tr><td width="171"><span class=testimonialFont>"Site Meter is the standard!"</span>
			<div class=testimonialFontQuote style="width: 161; height: 19"><a href="http://www.treehugger.com/" target="_blank">GH - Treehugger.com</div></td></tr>
			
			<tr><td width="171"><div class=testimonialFont>"Thanks Sitemeter! - We enjoyed a recent surge in visitors and your statistics helped me identify when and why."</div>
			<div class=testimonialFontQuote style="width: 161; height: 19"><a href="http://american-reporter.com" target="_blank">JS-www.american-reporter.com</div></td></tr>
			</table>
		</div>
	</td></tr>
	<tr><td><img src=images/homepage/testimonial_bottom_border.gif></td></tr>
	<!--<tr><td colspan=2> <div><iframe src=footer_banner_test.html width=800 height=175 frameborder=0> </div> </td></tr>-->
</table>

<!-- Site Meter -->
<a href="http://s35.sitemeter.com/stats.asp?site=s35sitemeterhp" target="_top">
<img src="http://s35.sitemeter.com/meter.asp?site=s35sitemeterhp" alt="Site Meter" border="0"/></a>
<!-- Copyright (c)2006 Site Meter --> </td>
	  </tr>	   

</table>

				 	  	 	</td>	  	
					
				    <td valign ="top" align="left" height="800">
						<!-- *** NOTEBOOKS.COM *** --><style>
.question{font-weight: bold; font-family: Arial, Helvetica, san-serif; }
.response{ font-family: Arial, Helvetica, san-serif; }
.interview{font-size: 12px; padding: 20px;}
</style>

<div class="interview">

	<div>
		<div align="left" style="float: left;"><a href="http://www.notebooks.com" target="_blank"><img src="/images/notebooks_com.png"  width="250" height="30" border="0" title="Click here to visit our Featured Site"></a><br>
		</div>
		<div align="left" style="font-size: 9px; float: right;">
			<TABLE BORDER=0 CELLPADDING=0 cellspacing=0 style="font-size: 9px;">
					<TR>
						<TD>
						<b>Read Past Featured Site Interviews</b>
						</TD>
					</TR>
					<TR>
						<TD class="lnHeight">
						<UL>
						<LI><a href="/?a=THEADVENTURELIFE" target="_blank">The Adventure Life</a> </LI>
						<LI><a href="/?a=CARRIBEANVIBESRADIO" target="_blank">Caribbean Vibes Radio</a> </LI>
						<LI><a href="/?a=SECONDCHANCETOLIVE" target="_blank">Second Chance to Live</a> </LI>
						<LI><a href="/?a=FUNFISHTANK" target="_blank">Fun Fish Tank</a> </LI>
						<LI><a href="/?a=GATEWORLD" target="_blank">Gateworld</a> </LI>
						<LI><a href="/?a=notebooks.com" target="_blank">Notebooks.com</a> </LI>
						<LI><a href="/?a=ITSJERRYTIME" target="_blank">It's Jerry Time</a></LI>
						<LI><a href="/?a=OFFICESNAPSHOTS" target="_blank">Office Snapshots</a></LI>
						<LI><a href="/?a=URBANGARDEN" target="_blank">My Urban Garden Deco Guide</a></LI>
						<LI><a href="/?a=ANGRYALIENFEATURE" target="_blank">Angry Alien Productions</a></LI>
						<LI><a href="/?a=18THCCUISINE" target="_blank">18thC Cuisine</a> </LI>
						<LI><a href="/?a=davidslongbox" target="_blank">Davids Long Box</a> </LI>
						</UL>
						</TD>
					</TR>
			</TABLE>
		</div>
	</div>
	<div style="clear:right;">
	<br><br>
<span class="question">Hi Xavier � thanks for taking time to visit with us and telling us a little about your site. </span><br><br>

<span class="question">Perhaps you can begin by telling us a little about yourself.  </span><br>
<span class="response">My name is Xavier and I live in San Francisco, California. I like almost anything that has batteries, and even more if it�s got WiFi. I have a degree in journalism from Cal Poly, a school better know for computer science and engineering. I worked in the corporate world before starting Notebooks.com. </span><br><br>

<span class="question">Where did you get the idea for your site, was it an original thought or based on something you had seen?</span><br>
<span class="response">I started Notebooks.com because I�m obsessed with mobile technology. I really enjoyed reading tech blogs, and thought it�d be cool to have one focused on notebook computers, which are the cornerstone of mobile technology.</span><br><br>

<span class="question">Was/is this the first site � Do you have other sites? </span><br>
<span class="response">This is my first commercial site. I have some super-secret smaller projects, but Notebooks.com takes almost all of my time.</span><br><br>



<span class="question">Where do you come up with the content?  </span><br>
<span class="response">We interview product managers at some of the best-known tech companies and attend conferences such as the Consumer Electronics Show in Las Vegas and Macworld in San Francisco. I've flown as far as China to attend a mobile tech summit to interview technology execs.</span><br><br>

<span class="question">Do you find these tech companies to be easily accessible? If you�re not a major magazine, newspaper or TV show are you really able to talk to them?</span><br>
<span class="response">It really depends on how new-media savvy the companies are. Fortunately, most of the companies I deal with understand the impact of social media and recognize that consumers are much more likely to research products before they buy them online than anywhere else. More people who are actively looking to buy a computer read Notebooks.com than most newspapers.<br><br>
The tech companies really do take Notebooks.com seriously, even though we�re not New York Times or CNN. I just got back from CES, where I had lunch with HP�s CTO, met Seagate�s CEO, interviewed Lenovo�s VP of marketing and one of the founders of VooDoo PC.<br><br>
It can be intimidating for bloggers to pick up the phone and ask for an interview. But if you build a reputation in your niche you�ll find that these big companies will start reaching out to you�phone�s ringing (brb)�.ok I�m back, that was a PR rep from one of the top PC companies checking in to make sure I had everything I needed from the show. I read the above question to her and she said our blog is on their 'Tier 1' media list.  
</span><br><br>

<span class="question">This is the first site we have interviewed who does �How To�s�.  How much time on average does it take to create one or your �How To� productions?</span><br>
<span class="response">We haven�t done that many how-to�s, but I need to get off my rear and start making more of them. A simple how-to can take less than 10 minutes, a more complex one with videos and screen grabs can take up to three hours. </span><br><br>

<span class="question">In terms of traffic and visits how successful are these How To areas?  Do they do worse or better than your blog posts?</span><br>
<span class="response">How-to�s perform very well for us in the long term, but it takes time to build steam behind them. People won�t generally read them until they have a problem. For example, one of our most popular articles on Notebooks.com explains how to reset an iPhone. Why would anyone read that if they didn�t have a crashed iPhone in front of them?  </span><br><br>

<span class="question">How many people does it require to run your site? </span><br>
<span class="response">I do the bulk of the site�s maintenance, a colleague handles a lot of the business affairs and we have guest contributors from time to time. We had a camera guy and another contributor help me cover CES 2008. We�re hoping to grow significantly in the new year. </span><br><br>

<span class="question">How much time do you spend working on your site on average a day?</span><br>
<span class="response">On an average day I spend about nine hours on the site, but I�ve spent as much as 23 hours per day on the site when things get busy, like on Black Friday or during trade shows. </span><br><br>

<span class="question">Is this website your primary job or do you also work elsewhere?</span><br>
<span class="response">Notebooks.com takes the bulk of my time and is my primary job. I do smaller web projects on the side. </span><br><br>

<span class="question">How long has it been live?</span><br>
<span class="response">The site has been live for almost two years, but we redesigned it and really got rolling in May of this year.</span><br><br>

<span class="question">How long have you used SiteMeter?</span><br>
<span class="response">We�ve used SiteMeter for more than a year.</span><br><br>

<span class="question">Can you give us a specific example of how SiteMeter�s stats and data have helped you?</span><br>
<span class="response">SiteMeter stats help me track traffic sources in real time in a very easy to use interface. We used SiteMeter during the holidays to track a number of metrics, including how quickly Google was indexing our site for certain search terms and which sites and blogs were linking to our Black Friday deals. We use another service from one of the big search companies too, but the stats take hours to load and it doesn�t give us as much info about what our readers are doing �right now.�</span><br><br>

<span class="question">One of things that I believe really intimidates people who are investigating getting into blogging and site ownership is they think they have to be extremely technical.  When you first started your site what was your level of internet experience? </span><br>
<span class="response">I�ve used the Internet for 13 years or so, which is more than most people. Like I said before, I have a degree in journalism, not computer science.<br><br>
You don�t need to have a technical background to get started. There are a lot of free and low-cost services for those who want to get started. I�d recommend starting with wordpress.com if you want to learn the ins and outs of a great blogging platform. If you want to manage a blogging platform on your own go with wordpress.org.<br><br>
Stick with a shared hosting plan to keep things simple, and make sure to choose a hosting company with a good reputation and 24/7 phone support. I have a friend who gets hundreds of thousands of page views per month and uses Media Temple�s grid service. Some people like Yahoo�s small business hosting because they never have to hold for a rep.
</span><br><br>

<span class="question">What if any strategies do you employ to drive traffic to your site?</span><br>
<span class="response">We get the bulk of our traffic from search engines and technology blogs. We allow other publishers to embed videos and excerpts of our content on their sites. This has worked really well, and sites such as ZDNet, TechMeme, Engadget.com and Gizmodo.com drive traffic to our site. </span><br><br>

<span class="question">What do you enjoy most about having a web/site?</span><br>
<span class="response">Running Notebooks.com means I get to see gadgets before anyone else and play with computers all day. What�s not to enjoy?  </span><br><br>

<span class="question">What is the biggest challenge you face in running a site like yours?</span><br>
<span class="response">There are literally thousands of tech blogs out there. It�s tough to stand out from the crowd.  </span><br><br>

<span class="question">From a financial perspective are you losing money, paying the bills, or making money from your site?</span><br>
<span class="response">We�re making money. </span><br><br>

<span class="question">For the benefit of our readers can I ask what your primary source of revenue is?  Your site doesn�t have that much advertising on it.</span><br>
<span class="response">Google ads do extremely well for us because our readers are usually looking to buy something, not just geek out. We also run affiliate programs with the PC manufacturers and e-tailers that do very well for us.  </span><br><br>

<span class="question">What are your future goals for the site?</span><br>
<span class="response">Notebooks.com is going to grow significantly in 2008. We want to build notebooks.com into a premier site for people looking to buy computers or solve computer problems. </span><br><br>



<span class="question">Thanks again Xavier.  We wish you all the best with your venture and look forward to seeing you make it big-ger very soon..<br><br>Visit Xavier's at <a href="http://www.notebooks.com" target="_blank">www.notebooks.com</a></span>

	</div>
	<br>

	
</div>


					</td>
				</tr>
				
				<tr>
					<td colspan="2">
						
	<table width="775" border="0" cellspacing="0" cellpadding="0" height="7" align="middle">
		<tr>
			<td width="775" valign="top" align="center" height="10" colspan="8" align="left">
				
<style>
a.userimages:link { color: #FFFFFF;text-decoration: none}
</style>

<table border=0 cellpadding=0 cellspacing=0>
	<tr><td><img src=images/homepage/footer_banner_top.gif width=780 height=11></td></tr>
	<tr><td valign=top background="images/homepage/footer_banner_repeat_border.gif" height=90 style="background-repeat: repeat-y; padding-left:10px;">
		<div>
		<span class=boxTitleFont>&nbsp;&nbsp;&nbsp;featured site meter users</span><br>
			<table align="center" width="770" cellpadding="5">
				<tr>
					<td align=center><a href="http://www.n4g.com" target="_blank" border="0"><img src="images/n4gLogo_jpeg2.gif" border="0" width="110" height="52"/></a></td>
					<td align=center><a href="http://www.giantbikes.net" target="_blank" class="userimages"><img src="images/giant_logo.png" border="0" width="154" height="31" /></a></td>
					<td align=center><a href="http://wonkette.com" target="_blank" class="userimages"><img src="images/wonkett.gif" border="0" width="199" height="39" /></a></td>
				</tr>
				
				<tr>
					<td align=center><a href="http://simplyrecipes.com/" target="_blank" class="userimages"><img src="images/homepage/simplerecipes.gif" border="0" width="234" height="40" /></a></td>
					<td align=center><a href="http://www.lazygirldesigns.com/blog" target="_blank" class="userimages"><img src="images/lazygirl.gif" border="0" width="217" height="50" /></a></td>
					<td align=center><a href="http://www.sbnation.com" target="_blank" class="userimages"><img src="images/sbn_logo.gif" border="0" width="199" height="38" /></a></td>
				</tr>
			</table>
		</div>
	</td></tr>
	<tr><td><img src=images/homepage/footer_banner_bottom.gif width=780 height=17></td></tr>
</table>

			</td>
		</tr>
	</table>

<table width="775" border="0" cellspacing="0" cellpadding="0" align="middle" style="margin-top: 10px; border-top: dotted 2px #969696;">
	<tr>
		<td nowrap align="left" style="padding-top:5px;  color: #333333;  font-size: 10pt; font-family: Arial, Helvetica, san-serif; padding-left:20px;">
				&copy;2009 Site Meter&nbsp;&nbsp;&nbsp;
				<font size="0" color="gray" face="Arial">
					<small>&nbsp;&nbsp;(0.01&nbsp;s)</small>
				03</font>&nbsp;
		</td>
		<td nowrap align="right" style="padding-top:5px; padding-right:20px;">
			<a href=".?a=privacy" id="privacy" name=privacy><font size="2" color="black" face="Arial">Privacy Statement</font></a>&nbsp;&nbsp;&nbsp;
			<a href=".?a=contact"><font size=2 color=black face="Arial">Contact</font></a>
		</td>
	</tr>	
</table><br>

<!-- Site Meter -->

<a href="http://s40.sitemeter.com/stats.asp?site=s40sitemeterhtml" target="_top">

<img src="http://s40.sitemeter.com/meter.asp?site=s40sitemeterhtml" alt="Site Meter" border="0"/></a>

<!-- Copyright (c)2006 Site Meter -->


<!-- Site Meter -->
<script type="text/javascript" src="http://sm2.sitemeter.com/js/counter.js?site=sm2sitemeter">
</script>
<noscript>
<a href="http://sm2.sitemeter.com/stats.asp?site=sm2sitemeter" target="_top">
<img src="http://sm2.sitemeter.com/meter.asp?site=sm2sitemeter" alt="Site Meter" border="0"/></a>
</noscript>
<!-- Copyright (c)2009 Site Meter -->




<script>
//document.write("<scr"+"ipt src='http://bp.specificclick.net?pixid=99000001&u="+escape(parent.document.location)+"&r="+escape(parent.document.referrer)+"'></scri"+"pt>");
</script>
<NOSCRIPT>
<!--<IMG SRC="http://bp.specificclick.net?pixid=99000001" width=0 height=0 border=0>-->
</NOSCRIPT>


<SCRIPT>
/*
var pid = 194;
var uid = Math.floor(Math.random() * 10000);
var rid = Math.floor(Math.random() * (new Date().getTime()));

document.write(
"<IFRAME FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=0 HEIGHT=0 src=\"javascript:location.href='http://ds.specificclick.net/?pid="+pid+"&uid="+uid+"&rid="+rid+"&u="+escape(parent.document.location)+"&r="+escape(parent.document.referrer)+"'; void 0;\"></IFRAME>" + 
"<IFRAME FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=0 HEIGHT=0 src=\"http://demo.bespecific.net/panama.php?cgroup=ron728x90&pid="+pid+"&uid="+uid+"&rid="+rid+"&kw=10&cx=10&bh=10\"</IFRAME>");
*/
</SCRIPT>



<script type="text/javascript"><!--
google_ad_client = "ca-pub-1394357781089131";
/* SiteMeter - LDR */
google_ad_slot = "8332674879";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
  
					</td>
					 
				</tr>
			</table>
	
		</td>
	</tr>
	</table>
	</div>
	
</div>

<script type='text/javascript' language='javascript'>

var dloc = document.location.toString();
if ((dloc == "http://sitemeter.com") | (dloc == "http://sitemeter.com/?a=home") | (dloc == "http://sitemeter.com/") | (dloc == "http://www.sitemeter.com/") | (dloc == "http://www.sitemeter.com") | (dloc == "http://www.sitemeter.com/?a=home"))
{


var cw = 840; // specify content width

var cp = 10; // specify the content padding if desired



try{

var s=document.createElement('script');

s.id='specific_rome_js';

s.type='text/javascript';

s.src='http://rome.specificclick.net/rome/rome.js?l=28095&t=j&cw='+cw+'&cp='+cp;

document.body.appendChild(s);

}catch(e){}
}


</script>



</body>
</html>
