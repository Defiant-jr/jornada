<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>

<title>Site Meter - Counter and Statistics Tracker</title>

<meta name="description" content="A fast, free Web counter that features custom counters styles. Site Meter creates dynamic 3D charts showing visitors, page views, country maps, visit durations and much more!">
<meta name="keywords" content="webstats, web counter, hit counter, free counter, Counter, web page counter, free web counter, free hit counter, tracker, web tracker, webtracker, free web tracker, webcounter, site statistics, page views, visits, javascript, web stats, log analyzer, log files, visitor reports, hits, visit reports, frontpage web counter, pagemill counter, dreamweaver counter, frontpage counter, site traffic, statistics log, traffic">


<LINK REL="SHORTCUT ICON" HREF="favicon.ico" >
<link rel="stylesheet" href="css/global.css" type="text/css">

<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://weblog.sitemeter.com/feed/" />
</head>


 
<body>
<div id="page" align="center">
 
				<div id="containerwide">
		 
	<table id="Table_01" width="783" height="500" border="0" cellpadding="0" cellspacing="0" valign="top" border="0" align="center">
		<tr>
			<td valign="middle">
				<table border="0" cellpadding="0" cellspacing="0" bgcolor="#333333" width="783">
				<tr>
				<td colspan="3"><img src="images/BannerAd_BorderTop.jpg" width="783" height="10"></td>
				</tr>
				<tr>
				<td><img src="images/BannerAd_BorderLeft.jpg" width="26" height="92"></td>
				<td width="732">
<!-- SM -->
<script type='text/javascript'>
<!--
var sm_random = Math.ceil(1000000*Math.random());
var u = '';
var r = '';
try
{
u = encodeURIComponent(document.location);
r = encodeURIComponent(document.referrer);
}catch(e){}
document.write("<scr"+"ipt type='text/javascript' src='http://afe.specificclick.net/?l=22018&sz=728x90&wr=j&t=j&u="+u+"&r="+r+"&rnd="+sm_random+"'></scr"+"ipt>");
//-->
</script>
</td>
				<td><img src="images/BannerAd_BorderRight.jpg" width="25" height="92"></td>
				</tr>
				<tr>
				<td colspan="3"><img src="images/BannerAd_BorderBottom.jpg" width="783" height="21"></td>
				</tr>

				</table>
			</td>
		</tr>
		<tr>
			<td align="center">

				<table id="Table_02" width="775" height="500" border="0" cellpadding="0" cellspacing="0" valign="top" border="0" style>
				
					<tr>
						<td colspan="2" valign="top" height="90">
						
<script LANGUAGE="JavaScript">
function callSearch()
{
document.siteform.submit;
}

function callfunction()
{
document.siteform.submit();
}

</script>
<form action="default.asp" method="POST" name="siteform" id="siteform" style="margin-top:0">
<input type="hidden" name="lastaction" value="HOME">
<input type="hidden" name="lastarea" value="">
<input type="hidden" name="lastpage" value="">



<table id="Table_01" border="0" cellpadding="0" cellspacing="0" align="left" style="margin-top:25px; width:775px;">
	<tr valign="top">
		<td width="326" height="44"><a href="/"><img src="images/sitemeter_logo.gif" width="226" height="44" alt="sitemeter" border=0></a></td>
	    <td  height="44" width="154"><img src="images/premium-prices_04.jpg" width="185" height="54" alt=""></td>
		<td width="150">
			<input style="margin-top:2px;" type='text' id='USERID'  class='detailedViewTextBox1'  name='USERID' value='' size="15" tabindex="1"><br>
			<input style="margin-top:5px;" type='password' name='PASSWORD'  class='detailedViewTextBox1' id='PASSWORD' value="" size="15" tabindex="2">
		</td>
		<td nowrap="nowrap" style="font-size:10px;font-family:arial;" width="150">
			<input tabindex=3 type="image" name="Login" src="images\LoginButton.jpg" width="70" height="25" border="0" onclick="javascript:callfunction();"><input  tabindex=3 type="hidden" name='LOGIN_BUTTON' value='login'><br>
			<input type="checkbox" name="Remember" value="True">Remember&nbsp;Me&nbsp;<br>
			&nbsp;<a href="/?a=loginform">forgot codename/password?</a>
   		</td>
	</tr>

	<tr><td colspan="4" height="11"><img src="images/greenbar.gif" width="775" height="6" alt=""></td></tr>
</table>
</form>
<script language="JavaScript" type="text/javascript">
<!--
	document.siteform.USERID.focus();
// -->
</script>&nbsp;
						</td>
					</tr>
			
					
						<tr>
							<td colspan="2" valign ="top">
							
<table width='700' border='1' cellspacing='0' cellpadding='0'  style="border-color:grey; border:1px; ">
<tr>
	<td  width="700" height="100" align="center">
      <p align="center">
	 <!-- <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="774" height="206">
    	  <param name="movie" value="sitemeterheader_singleframe.swf">
      	<param name="quality" value="high">
	      <embed src="sitemeterheader_singleframe.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="774" height="206"></embed></object>-->
        <script language="javascript" src="Js/flashfix.js"></script> 
		<div id="flash_container"></div>
		<script >
		 writeFlash('flash_container','sitemeterheader_singleframe.swf');
		</script>
      </p>
         
	    </td>
 	</tr>
</table>&nbsp;
							</td>
						</tr>
						<tr>
							<td colspan="2" valign ="top" height="10">&nbsp;</td>
						</tr>
					 				
				<tr>
				
							
							<td valign ="top" width="175" height="350" align="left">
							<table bgcolor="#FFFFFF" border="0" cellspacing="0" cellpadding="0" width="181" >
   
     <tr height="15">
  		
  			 	<td class='menuheader' height="15" width="179">
  			 		 <a href=".?a=home" STYLE="text-decoration:none">
   				<font size='2' face='Arial' color=White>&nbsp;&nbsp;home</font></a></td>
   	 </tr>
  
  <tr height="5">
	<Td width="179"></td>
			</tr>
			
   		<tr height="15">   
			<td height="15" class="menuheader" width="179" >&nbsp&nbsp learn more</td>
		</tr>
		
	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=howworks">How Does Site Meter Work?</a></td>
	  </tr>
	  
	  <tr height="15">
        <td class="menuitem" height="15" width="179" >Site Meter Basic</td>
	  </tr>
 	  <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href="/flash/basic_account/basic_account.html" target=_blank>Tour</a>      </td>
        </tr>     
	  <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href=".?a=samplestats&HELP=ON">Demo Stats</a>      </td>
        </tr>
        
        <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href=".?a=counterstyles">Meter Options</a>    	    </td>
        </tr>
        
        <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href=".?a=signupoptions">Sign Up</a>    </td>
        </tr>
        
   	    <tr height="15">
           <td class="menuitem" height="15" width="179" >Site Meter Premium</td>
        </tr>
        

 	  <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href="/flash/premium_tour/premium_tour.html" target=_blank>Tour</a>      </td>
        </tr>    

        <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href=".?a=sampleprostats&HELP=ON">Demo Stats</a>      </td>
        </tr>

        <tr height="15">
        	<td class="menusubitem" height="15" width="179" ><a href=".?a=premiumprices">Pricing</a> </td>
        </tr>
    
	    <tr height="15">
			<td class="menusubitem" height="15" width="179" ><a href=".?a=signupoptions">Sign Up</a>	        </td>
        </tr>
        
        <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=productcomparison">Product Comparison</a></td>
	  	</tr>  
	  
	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href="http://support.sitemeter.com/index.php?_m=knowledgebase&_a=view&parentcategoryid=1&pcid=0&nav=0">FAQ-General Info</a></td>
	  </tr>
       
       
      <tr height="15">
        <td class="menuheader" height="15" width="179" >&nbsp&nbsp news + announcements</td>
	  </tr>	          
    
	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a  target="_blank" href="http://sitemeter.wordpress.com/">News/Announcements Blog </a></td>
	  </tr>  
	
	     <tr height="15">
    
        <td class="menuheader" height="15" width="179" >&nbsp&nbsp support + service</td>
	  </tr>	          
    
		<tr height="15">
        <td class="menuitem" height="15" width="179" ><a href="http://support.sitemeter.com">KnowledgeCenter</a></td>
		</tr> 

		<tr height="15">
        <td class="menuitem" height="15" width="179" ><a href="http://support.sitemeter.com/index.php?_m=tickets&_a=submit">Submit Support Request</a></td>
		</tr> 

	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=signupoptions">Upgrade Account</a></td>
	  </tr> 
	  
     <tr height="15">
        <td class="menuheader" height="15" width="179" >&nbsp&nbsp about us</td>
	  </tr>	          
      
      <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=contact">Contact Info</a></td>
	  </tr>  
	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=privacy">Privacy Policy</a></td>
	  </tr>      
	  <tr height="15">
        <td class="menuitem" height="15" width="179" ><a href=".?a=joinus">Join Us</a></td>
	  </tr> 
		  <tr height="15">
        <td  height="15" width="179" >&nbsp;</td>
	  </tr>   
	 <tr >
        <td  width="179" ><!--[if lt IE 7.]>
<script defer type="text/javascript" src="Js/pngfix.js"></script>
<![endif]-->
<table border=0 cellpadding=0 cellspacing=0>
	<tr><td><img src="images/partners_top_border.gif" width=212 height=16></td></tr>
	<tr>
		<td valign=top background="images/partners_repeat_border.gif" style="background-repeat: repeat-y; ">
		<div class=boxTitleFont>&nbsp;&nbsp;&nbsp;site meter partners<br></div>
		<table align=center style="padding-top:4px;">
			
			<tr>
				<td align=center style="padding-left:7px;"><a href="http://webanalyticsbook.com/" alt="Web Analytics Book" target=_blank border=0>
<img border='0' src='images/webanalytics.gif' width=150 height=43></a></td>
			</tr>
			<tr>
				<td align=center style="padding-left:7px; "><a href="http://blogherald.com/" alt="Blog Herald" target=_blank>
<img border='0' src='images/blogherald.gif' width=150 height=43></a></td>
			</tr>
			<tr>
				<td align=center style="padding-left:7px; "><a href="http://www.readwriteweb.com/" alt="Read/Write Web" target=_blank>
<img border='0' src='images/readwrite.gif' width=150 height=43></a></td>
			</tr>
			

			
		</table>
		<div class=boxTitleFont><br>&nbsp;&nbsp;&nbsp;site meter eco-ranking<br></div>
		<table align=center style="padding-top:4px;">
			<tr>
				<td align=center style="padding-left:7px; "><a href="http://truthlaidbear.com/ecotraffic.php" alt="The Truth Laid Bear" target=_blank>
					<img border='0' src='images/ttlb.png' width=150 height=43></a>
				</td>
			</tr>
		</table>
		</td>
	</tr>


	<tr><td><img src="images/partners_bottom_border.gif" width=212 height=15></td></tr>
</table> </td>
	  </tr> 	 

 <tr>
        <td width="179"> 
<table border=0 cellpadding=0 cellspacing=0>
	<tr><td><img src=images/homepage/testimonial_top_border.gif></td></tr>
	<tr><td valign=top background="images/homepage/testimonial_repeat_border.gif" height=205 style="background-repeat: repeat-y; ">
		<span class=boxTitleFont>&nbsp;&nbsp;&nbsp;testimonials</span>
		<div style="padding-left:13px; padding-top:2px; padding-right:10px; width:190px; vertical-align:middle;">
			<table height="235px;" width="179">
			<tr><td width="171"><div class=testimonialFont>"I love Site Meter. I recommend it to everyone..."</div>
			<div class=testimonialFontQuote style="width: 161; height: 19"><a href="http://simplyrecipes.com/" target="_blank">EB - SimplyRecipes</div></td></tr>
				
			<tr><td width="171"><span class=testimonialFont>"Site Meter is the standard!"</span>
			<div class=testimonialFontQuote style="width: 161; height: 19"><a href="http://www.treehugger.com/" target="_blank">GH - Treehugger.com</div></td></tr>
			
			<tr><td width="171"><div class=testimonialFont>"Thanks Sitemeter! - We enjoyed a recent surge in visitors and your statistics helped me identify when and why."</div>
			<div class=testimonialFontQuote style="width: 161; height: 19"><a href="http://american-reporter.com" target="_blank">JS-www.american-reporter.com</div></td></tr>
			</table>
		</div>
	</td></tr>
	<tr><td><img src=images/homepage/testimonial_bottom_border.gif></td></tr>
	<!--<tr><td colspan=2> <div><iframe src=footer_banner_test.html width=800 height=175 frameborder=0> </div> </td></tr>-->
</table>

<!-- Site Meter -->
<a href="http://s35.sitemeter.com/stats.asp?site=s35sitemeterhp" target="_top">
<img src="http://s35.sitemeter.com/meter.asp?site=s35sitemeterhp" alt="Site Meter" border="0"/></a>
<!-- Copyright (c)2006 Site Meter --> </td>
	  </tr>	   

</table>

				 	  	 	</td>	  	
					
				    <td valign ="top" align="left" height="800">
						<!-- *** HOME *** --><table width='500' border=0>
	<tr>
		<td valign='top'>
		<table>
			<tr>
				<td valign='top'>
				  
 
 <link rel="stylesheet" type="text/css" href="/downloaded_feeds/sitemeter_rss_aggregator.css" />
 <!--[if IE]> <link href="/downloaded_feeds/sitemeter_rss_aggregator_ie.css" rel="stylesheet" type="text/css"> <![endif]-->
 <table border=0 cellpadding=0 cellspacing=0 width="563">
  <tr> 
    <td valign=top width="257"> <table border=0 cellpadding=0 cellspacing=0>
        <tr>
          <td><img src="images/homepage/graph.jpg" width="253" height="174" alt=""></td>
        </tr>
        <tr>
          <td><img src="images/homepage/weblog_box_top_border.gif" width="245" height="24" alt=""></td>
        </tr>
        <tr>
          <td valign=top background="images/homepage/weblog_box_repeat_border.gif" height=226 style="background-repeat: repeat-y; padding-left:10px;"> 
          <h1 class="sitemeter_rss_aggregator"><a href="http://sitemeter.wordpress.com/" target="_blank">Site Meter News/Announcements</a></h1><br />
          <p class="sitemeter_rss_aggregator">
<a href="http://sitemeter.wordpress.com/2009/02/19/something-to-consider-fyi/" class="sitemeter_rss_aggregator">Something to Consider FYI</a><br />
We recognize that there are a whole host of reasons people choose to create websites and blogs and not everyone is looking to make money from their efforts.� For many, websites and blogs are a tool for marketing your products &#8230; <a href="http://sitemeter.wordpress.com/2009/02/19/something-to-co...</p>
<p class="sitemeter_rss_aggregator">
<a href="http://sitemeter.wordpress.com/2008/06/18/new-sitemeter-windows-vista-gadget/" class="sitemeter_rss_aggregator">New SiteMeter Windows Vista Gadget</a><br />
As many of you are aware SiteMeter has developed a Yahoo Widget that allows you to view your sites daily page views and visit totals ?live?, on your computer?s desktop, as they happen. A few months back we were introduced &#8230; <a href="http://sitemeter.wordpress.com/2008/06/18/new-sitemeter-windo...</p>

          <div style="text-align:right; padding-right:30px;"><span style="font-size: 8pt; color: darkgreen; font-weight: bold; ">Web Feed&nbsp;&nbsp;&nbsp;</span><img src="/images/rss_image.gif" border=0 width=24 height=24 usemap="#sitemeter_webfeed"></div></td>
        </tr>
		<map name="sitemeter_webfeed">
		<area shape="rect" alt="" coords="53,0,87,33" href="http://weblog.sitemeter.com/feed/" target="_blank">
		<area shape="rect" alt="" coords="0,0,53,32" href="http://weblog.sitemeter.com/feed/" target="_blank">
		</map>
        <tr>
          <td><img src="images/homepage/weblog_box_bottom_border.gif" width="245" height="14" alt=""></td>
        </tr>
        <tr>
          <td style=padding-top:3px;><img src="images/spacer.gif" height=0 width=4><img src="images/homepage/topvisitedsites_box_top_border.gif" width="238" height="65" alt="" usemap="#truthlaidbear" border=0></td>
        </tr>
			<map name="truthlaidbear">
				<area shape="rect" alt="" coords="86,15,237,51" href="http://truthlaidbear.com/ecotraffic.php" target="_blank">
			</map>
        <tr>
          <td valign=top background="images/homepage/topVisitedSites_repeat_border.gif" height=180 style="background-repeat: repeat-y; padding-left:10px;"> 
            <!--<span class=boxTitleFont style=" padding-left:10px; "><b>site meter's</b></span>
<br>
<span class=boxTitleFont style=" padding-left:10px; "><b>top visited sites</b>
<br>
<br></span>-->
            <span class=boxTitleFont style="padding-left:17px;"><b>1.</b></span> 
            &nbsp;<a href="http://www.perezhilton.com" class="topVisitedSitesLinks"  target="_blank">www.perezhilton.com</a><br> 
            <span class=boxTitleFont style="padding-left:17px;"><b>2.</b></span> 
            &nbsp;<a href="http://www.andkon.com/arcade" class="topVisitedSitesLinks" target="_blank">www.andkon.com/arcade</a><br> 
            <span class=boxTitleFont style="padding-left:17px;"><b>3.</b></span> 
            &nbsp;<a href="http://www.gizmodo.com" class="topVisitedSitesLinks" target="_blank">www.gizmodo.com</a><br> 
            <span class=boxTitleFont style="padding-left:17px;"><b>4.</b></span> 
            &nbsp;<a href="http://www.kotaku.com" class="topVisitedSitesLinks" target="_blank">www.kotaku.com</a><br> 
            <span class=boxTitleFont style="padding-left:17px;"><b>5.</b></span> 
            &nbsp;<a href="http://www.lifehacker.com" class="topVisitedSitesLinks" target="_blank">www.lifehacker.com</a><br> 
            <span class=boxTitleFont style="padding-left:17px;"><b>6.</b></span> 
            &nbsp;<a href="http://www.autoblog.com" class="topVisitedSitesLinks" target="_blank">www.autoblog.com</a><br> 
            <span class=boxTitleFont style="padding-left:17px;"><b>7.</b></span> 
            &nbsp;<a href="http://www.dailykos.com" class="topVisitedSitesLinks" target="_blank">www.dailykos.com</a><br> 
            <span class=boxTitleFont style="padding-left:17px;"><b>8.</b></span> 
            &nbsp;<a href="http://www.gawker.com" class="topVisitedSitesLinks" target="_blank">www.gawker.com</a><br> 
            <span class=boxTitleFont style="padding-left:17px;"><b>9.</b></span> 
            &nbsp;<a href="http://www.video4viet.com" class="topVisitedSitesLinks" target="_blank">www.video4viet.com</a><br>
            <span class=boxTitleFont style="padding-left:17px;"><b>10.</b></span> 
            <a href="http://www.jezebel.com" class="topVisitedSitesLinks" target="_blank">www.jezebel.com</a><br>
			<span class=boxTitleFont style="padding-left:17px;"><b>11.</b></span> 
            <a href="http://www.jalopnik.com" class="topVisitedSitesLinks" target="_blank">www.jalopnik.com</a><br>
            <span class=boxTitleFont style="padding-left:17px;"><b>12.</b></span> 
            <a href="http://www.n4g.com" class="topVisitedSitesLinks"  target="_blank">www.n4g.com</a><br> 
			<span class=boxTitleFont style="padding-left:17px;"><b>13.</b></span> 
            <a href="http://www.stockq.org" class="topVisitedSitesLinks" target="_blank">www.stockq.org</a><br>
			<span class=boxTitleFont style="padding-left:17px;"><b>14.</b></span> 
            <a href="http://www.recadopop.com" class="topVisitedSitesLinks" target="_blank">www.recadopop.com</a><br>
			<span class=boxTitleFont style="padding-left:17px;"><b>15.</b></span> 
            <a href="http://www.deadspin.com" class="topVisitedSitesLinks" target="_blank">www.deadspin.com</a><br>
			<span class=boxTitleFont style="padding-left:17px;"><b>16.</b></span> 
            <a href="http://www.justjared.com" class="topVisitedSitesLinks" target="_blank">www.justjared.com</a><br>
			<span class=boxTitleFont style="padding-left:17px;"><b>17.</b></span> 
            <a href="http://www.hotair.com" class="topVisitedSitesLinks" target="_blank">www.hotair.com</a><br>
		    <span class=boxTitleFont style="padding-left:17px;"><b>18.</b></span> 
            <a href="http://www.consumerist.com" class="topVisitedSitesLinks" target="_blank">www.consumerist.com</a><br>
            <span class=boxTitleFont style="padding-left:17px;"><b>19.</b></span> 
            <a href="http://www.sbnation.com" class="topVisitedSitesLinks" target="_blank">www.sbnation.com</a><br> 
            <span class=boxTitleFont style="padding-left:17px;"><b>20.</b></span> 
            <a href="http://www.surfmusik.de" class="topVisitedSitesLinks" target="_blank">www.surfmusik.de</a><br>



          </td>
        </tr>
        <tr>
          <td><img src="images/homepage/topVisitedSites_bottom_border.gif" width="245" height="19" alt=""></td>
        </tr>
      </table></td>
    <!--new row start -->
    <td valign=top width="318"> <table border=0 cellpadding=0 cellspacing=0>
        <tr>
          <td><!--<img src="images/homepage/Sitemeter_Answers_Title.jpg" width="314" height="40" alt="Site Meter Can Provide the Answers!">-->
		  <span style="font-size:17px; font-family: Arial; font-weight: bold; padding-left:8px; padding-bottom: 10px;">Site Meter Can Provide the Answers!</span></td>
        </tr>
        <tr>
          <td width=314 height=122 valign=top> <div valign="top" align="left" style="padding-left:8px"><span class="style4"><strong style=color:#3F3F3F;>Site 
              Meter's</strong> comprehensive real time website tracking and counter 
              tools give you instant access to vital information and data about 
              your sites audience. With our detailed reporting you'll have a clear 
              picture of who is visiting your site, how they found you, where 
              they came from, what interests them and much more.</span></div></td>
        </tr>
		<tr>
          <td valign=top><img src="images/homepage/advertisement_header.jpg" width="314" height="16" alt=""></td>
        </tr>
        <tr>
          <td valign=top style=padding-top:4px; align="center"> 
			<!-- Start Ad -->
			 <script type='text/javascript'>
<!--
var sm_random = Math.ceil(1000000*Math.random());
var u = '';
var r = '';
try
{
u = encodeURIComponent(document.location);
r = encodeURIComponent(document.referrer);
}catch(e){}
document.write("<scr"+"ipt type='text/javascript' src='http://afe.specificclick.net/?l=2974&sz=300x250&wr=j&t=j&u="+u+"&r="+r+"&rnd="+sm_random+"'></scr"+"ipt>");
//-->
</script>


          </td>
        </tr>
<!--featured story section -->
        <tr>
          <td valign=top style=padding-top:6px;><img src="images/homepage/webAnalytics_top_border.gif" width="314" height="16" alt=""></td>
        </tr>
        <tr>
          <td valign=top  background="images/homepage/webAnalytics_repeat_border.gif"  style="background-repeat: repeat-y; padding-left:10px;"> 
		   
            <span class="sitemeter_rss_aggregator" style="font-size: 11px; font-weight: bold; padding-bottom: 10px;">This month's Featured Site<br></span>
			<div id="FeaturedSiteImage" style="padding-left: 13px; padding-top: 10px;"><a href="/?a=THEADVENTURELIFE"><img src="/images/theadventurelife07.jpg" border="0"></a><br></div>
			
			<div id="FeaturedSiteImage" style="padding-left: 13px; padding-bottom: 3px;"><a href="/?a=THEADVENTURELIFE" class="topVisitedSitesLinks" >click here to read full interview</a></div>
			

		  </td>
        </tr>
        <tr>
          <td valign=top><img src="images/homepage/webAnalytics_bottom_border.gif" width="314" height="12" alt=""></td>
        </tr>
		<!--featured story section end -->




        <tr>
          <td valign=top style=padding-top:6px;><img src="images/homepage/webAnalytics_top_border.gif" width="314" height="16" alt=""></td>
        </tr>
        <tr>
          <td valign=top  background="images/homepage/webAnalytics_repeat_border.gif"  style="background-repeat: repeat-y; padding-left:10px;"> 
            <!--<span class=boxTitleFont ><b>web analytics news</b></span>-->
		   
            <h1 class="sitemeter_rss_aggregator"><a href="http://www.webanalyticsbook.com" target="_blank">Webanalyticsbook</a></h1><br />
            <p class="sitemeter_rss_aggregator">
<a href="http://feedproxy.google.com/~r/webanalyticsbook/~3/pAv1TW3j6WM/" class="sitemeter_rss_aggregator">Tracking Social Media Engagement</a><br />
Tracking social media engagement is difficult to do. Unless you simplify it and concentrate on Shares, Likes, Tweets and Google+s. And that&#8217;s ex...</p>
<p class="sitemeter_rss_aggregator">
<a href="http://feedproxy.google.com/~r/webanalyticsbook/~3/D0-D1M_hPvA/" class="sitemeter_rss_aggregator">Google Analytics Premium Going After Adobe?s Sitecatalyst</a><br />
While most Analytics vendors turned a little bit quite over the past few months, Google now popped up again with big news: Google Analytics Premium. T...</p>

            <div style="text-align:right; padding-right:30px;"><span style="font-size: 8pt; color: darkgreen; font-weight: bold;">Web Feed&nbsp;&nbsp;&nbsp;</span><img src="/images/rss_image.gif" border=0 width=24 height=24 usemap="#webanalytic_webfeed"></div>
			<map name="webanalytic_webfeed">
				<area shape="rect" alt="" coords="53,0,87,33" href="http://feeds.feedburner.com/webanalyticsbook?format=xml" target="_blank">
				<area shape="rect" alt="" coords="0,0,53,32" href="http://feeds.feedburner.com/webanalyticsbook?format=xml" target="_blank">
			</map>
			</td>
        </tr>
        <tr>
          <td valign=top><img src="images/homepage/webAnalytics_bottom_border.gif" width="314" height="12" alt=""></td>
        </tr>
		

       
        <tr>
          <td></td>
        </tr>
      </table></td>
  </tr>
</table>

				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
					</td>
				</tr>
				
				<tr>
					<td colspan="2">
						
	<table width="775" border="0" cellspacing="0" cellpadding="0" height="7" align="middle">
		<tr>
			<td width="775" valign="top" align="center" height="10" colspan="8" align="left">
				
<style>
a.userimages:link { color: #FFFFFF;text-decoration: none}
</style>

<table border=0 cellpadding=0 cellspacing=0>
	<tr><td><img src=images/homepage/footer_banner_top.gif width=780 height=11></td></tr>
	<tr><td valign=top background="images/homepage/footer_banner_repeat_border.gif" height=90 style="background-repeat: repeat-y; padding-left:10px;">
		<div>
		<span class=boxTitleFont>&nbsp;&nbsp;&nbsp;featured site meter users</span><br>
			<table align="center" width="770" cellpadding="5">
				<tr>
					<td align=center><a href="http://www.n4g.com" target="_blank" border="0"><img src="images/n4gLogo_jpeg2.gif" border="0" width="110" height="52"/></a></td>
					<td align=center><a href="http://www.giantbikes.net" target="_blank" class="userimages"><img src="images/giant_logo.png" border="0" width="154" height="31" /></a></td>
					<td align=center><a href="http://wonkette.com" target="_blank" class="userimages"><img src="images/wonkett.gif" border="0" width="199" height="39" /></a></td>
				</tr>
				
				<tr>
					<td align=center><a href="http://simplyrecipes.com/" target="_blank" class="userimages"><img src="images/homepage/simplerecipes.gif" border="0" width="234" height="40" /></a></td>
					<td align=center><a href="http://www.lazygirldesigns.com/blog" target="_blank" class="userimages"><img src="images/lazygirl.gif" border="0" width="217" height="50" /></a></td>
					<td align=center><a href="http://www.sbnation.com" target="_blank" class="userimages"><img src="images/sbn_logo.gif" border="0" width="199" height="38" /></a></td>
				</tr>
			</table>
		</div>
	</td></tr>
	<tr><td><img src=images/homepage/footer_banner_bottom.gif width=780 height=17></td></tr>
</table>

			</td>
		</tr>
	</table>

<table width="775" border="0" cellspacing="0" cellpadding="0" align="middle" style="margin-top: 10px; border-top: dotted 2px #969696;">
	<tr>
		<td nowrap align="left" style="padding-top:5px;  color: #333333;  font-size: 10pt; font-family: Arial, Helvetica, san-serif; padding-left:20px;">
				&copy;2009 Site Meter&nbsp;&nbsp;&nbsp;
				<font size="0" color="gray" face="Arial">
					<small>&nbsp;&nbsp;(0.01&nbsp;s)</small>
				03</font>&nbsp;
		</td>
		<td nowrap align="right" style="padding-top:5px; padding-right:20px;">
			<a href=".?a=privacy" id="privacy" name=privacy><font size="2" color="black" face="Arial">Privacy Statement</font></a>&nbsp;&nbsp;&nbsp;
			<a href=".?a=contact"><font size=2 color=black face="Arial">Contact</font></a>
		</td>
	</tr>	
</table><br>

<!-- Site Meter -->

<a href="http://s40.sitemeter.com/stats.asp?site=s40sitemeterhtml" target="_top">

<img src="http://s40.sitemeter.com/meter.asp?site=s40sitemeterhtml" alt="Site Meter" border="0"/></a>

<!-- Copyright (c)2006 Site Meter -->


<!-- Site Meter -->
<script type="text/javascript" src="http://sm2.sitemeter.com/js/counter.js?site=sm2sitemeter">
</script>
<noscript>
<a href="http://sm2.sitemeter.com/stats.asp?site=sm2sitemeter" target="_top">
<img src="http://sm2.sitemeter.com/meter.asp?site=sm2sitemeter" alt="Site Meter" border="0"/></a>
</noscript>
<!-- Copyright (c)2009 Site Meter -->




<script>
//document.write("<scr"+"ipt src='http://bp.specificclick.net?pixid=99000001&u="+escape(parent.document.location)+"&r="+escape(parent.document.referrer)+"'></scri"+"pt>");
</script>
<NOSCRIPT>
<!--<IMG SRC="http://bp.specificclick.net?pixid=99000001" width=0 height=0 border=0>-->
</NOSCRIPT>


<SCRIPT>
/*
var pid = 194;
var uid = Math.floor(Math.random() * 10000);
var rid = Math.floor(Math.random() * (new Date().getTime()));

document.write(
"<IFRAME FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=0 HEIGHT=0 src=\"javascript:location.href='http://ds.specificclick.net/?pid="+pid+"&uid="+uid+"&rid="+rid+"&u="+escape(parent.document.location)+"&r="+escape(parent.document.referrer)+"'; void 0;\"></IFRAME>" + 
"<IFRAME FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=0 HEIGHT=0 src=\"http://demo.bespecific.net/panama.php?cgroup=ron728x90&pid="+pid+"&uid="+uid+"&rid="+rid+"&kw=10&cx=10&bh=10\"</IFRAME>");
*/
</SCRIPT>



<script type="text/javascript"><!--
google_ad_client = "ca-pub-1394357781089131";
/* SiteMeter - LDR */
google_ad_slot = "8332674879";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
  
					</td>
					 
				</tr>
			</table>
	
		</td>
	</tr>
	</table>
	</div>
	
</div>

<script type='text/javascript' language='javascript'>

var dloc = document.location.toString();
if ((dloc == "http://sitemeter.com") | (dloc == "http://sitemeter.com/?a=home") | (dloc == "http://sitemeter.com/") | (dloc == "http://www.sitemeter.com/") | (dloc == "http://www.sitemeter.com") | (dloc == "http://www.sitemeter.com/?a=home"))
{


var cw = 840; // specify content width

var cp = 10; // specify the content padding if desired



try{

var s=document.createElement('script');

s.id='specific_rome_js';

s.type='text/javascript';

s.src='http://rome.specificclick.net/rome/rome.js?l=28095&t=j&cw='+cw+'&cp='+cp;

document.body.appendChild(s);

}catch(e){}
}


</script>



</body>
</html>
